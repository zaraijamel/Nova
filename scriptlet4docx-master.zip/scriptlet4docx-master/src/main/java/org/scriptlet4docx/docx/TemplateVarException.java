package org.scriptlet4docx.docx;

public class TemplateVarException extends RuntimeException {
	/**
	 * 
	 */
	private static final long serialVersionUID = 5449631122625751450L;

	public TemplateVarException(String msg) {
		super(msg);
	}
}
